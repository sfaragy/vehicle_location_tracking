module.exports = { 
  content: [
    "./views/*.{js,ejs,html}",
    "./views/**/*.{js,ejs,html}"
  ],
  theme: {
    extend: {},
  },
  plugins: [],
}